import java.util.ArrayList;

/*
 * Homework 3
 * Zach Lieberman, zl5nrs
 * 
 * Sources: My head.
 */
public class Album extends PhotographContainer{
	
	private ArrayList<Photograph> photos = new ArrayList<Photograph>();
	
	public Album(String name)
	{
		super(name);
	}
	
	
}
